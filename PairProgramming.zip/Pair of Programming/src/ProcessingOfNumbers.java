/* Troy Mosqueda
 * October 12, 2022
 * Programming Pair code that accepts user inputs and keeps a running sum of all even numbers 
 * while also keeping track of min and max values 
 */

import java.util.Scanner;
//add a main method
public class ProcessingOfNumbers {
	Scanner input = new Scanner(System.in);
	public static boolean ifEven(int num) {
		boolean even = true;
		if (num%2==0) {
			even = true;
		}else {
			even = false;
		}
		return even;
	}
	public static int sumEven(int runningSum, int newNum) {
			runningSum += newNum;
			return runningSum;
	}
	public static int maxEven(int currentMax, int compare) {	
		if (compare>currentMax) {
			currentMax = compare;
		}else {
			return currentMax;
		}
		return currentMax;
	 }
	public static int Max(int currentMax, int compare) {
		if(compare>currentMax) {
			currentMax = compare;
		}else {
			return currentMax;
		}
		return currentMax;
	}
	public static int Min(int currentMin, int compare) {
		if(compare<currentMin) {
			currentMin=compare;
		}else {
			return currentMin;
		}
		return currentMin;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String response = "";
		while(!response.equals("QUIT")) {
			System.out.print("Type in a number to represent the length of this series: ");
			int series = input.nextInt();
			int temp = 0;
			int min = 10000000;
			int max = 0;
			int maxEven = 0;
			int sum = 0;
			for (int i = 0; i< series; i++) {
				System.out.print("Input a number: ");
				int next = input.nextInt();
				if(next<min) {
					min = Min(min,next);
				}
				max = Max(max, next);
				if(next%2==0) {
					maxEven = maxEven(temp, next);
				}
				if(next%2==0) {
					sum = sumEven(sum, next);
				}
				temp = next;
			}
			System.out.println("Minimum " + min);
			System.out.println("Maximum " + max);
			System.out.println("maximum even number " + maxEven);
			System.out.println("Sum of evens: " + sum);
			System.out.println();
			//input.close();
			//response = input.nextLine();
			
			}
		input.close();
		
			
	}
}
	

